package proyecto_final_jgym;

public class Cliente extends Personas {
    private String date;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
