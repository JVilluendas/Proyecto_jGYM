package proyecto_final_jgym;

import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.net.URL;
import java.util.ArrayList;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Pantalla extends javax.swing.JFrame {

    LabelThread movimiento;

    private Point clickInicial;
    private ConexionjGym conexionjGym = new ConexionjGym();

    public Pantalla() {
        //Este primer Listener detecta el CLICK del ratón
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                clickInicial = e.getPoint();
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                clickInicial = null;
            }
        });
        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                // Si initialClick es null, significa que no empezamos arrastrando desde esta ventana
                if (clickInicial == null) {
                    return;
                }

                // Coordenadas actuales del ratón en la pantalla
                int thisX = getLocationOnScreen().x;
                int thisY = getLocationOnScreen().y;

                int xMoved = e.getXOnScreen() - clickInicial.x;
                int yMoved = e.getYOnScreen() - clickInicial.y;

                // Mueve la ventana a la nueva posición
                setLocation(xMoved, yMoved);
            }
        });

        initComponents();
        movimiento = new LabelThread(jLabel3);
        movimiento.start();
        movimiento = new LabelThread(jLabel7);
        movimiento.start();
        movimiento = new LabelThread(jLabel16);
        movimiento.start();
        movimiento = new LabelThread(jLabel19);
        movimiento.start();
        movimiento = new LabelThread(jLabel28);
        movimiento.start();
        movimiento = new LabelThread(jLabel35);
        movimiento.start();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pantallaPrincipal = new javax.swing.JDialog();
        selectorPrincipal = new javax.swing.JTabbedPane();
        panelPrincipalTablaDatos = new javax.swing.JPanel();
        scrollPaneTablaDatos = new javax.swing.JScrollPane();
        tablaDatos = new javax.swing.JTable();
        tituloBorrarLinea = new javax.swing.JLabel();
        buscarID = new javax.swing.JLabel();
        comboBoxElementoABuscar = new javax.swing.JComboBox<>();
        IDABuscar = new javax.swing.JLabel();
        textFieldIDABuscar = new javax.swing.JTextField();
        textFieldIDABorrar = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel38 = new javax.swing.JLabel();
        verDatosEmpleados = new javax.swing.JLabel();
        verDatosPersonas = new javax.swing.JLabel();
        verDatosMaterial = new javax.swing.JLabel();
        verDatosClases = new javax.swing.JLabel();
        verDatosAsistentes = new javax.swing.JLabel();
        verDatosMaterialUsado = new javax.swing.JLabel();
        verDatosClientes = new javax.swing.JLabel();
        botonBorrarLinea = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        botonBuscarConID = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        botonPersonasOrdenNombre = new javax.swing.JLabel();
        botonClasesRealizadas = new javax.swing.JLabel();
        botonNombreClasesMateriales = new javax.swing.JLabel();
        botonNombreEmpleadosSalario = new javax.swing.JLabel();
        panelPrincipalInsertarDatos = new javax.swing.JPanel();
        selectorInsertarDatos = new javax.swing.JTabbedPane();
        panelCliente = new javax.swing.JPanel();
        textFieldNombreCliente = new javax.swing.JTextField();
        textFieldDNICliente = new javax.swing.JTextField();
        textFieldDireccionCliente = new javax.swing.JTextField();
        textFieldFechaCliente = new javax.swing.JTextField();
        textFieldTelefonoCliente = new javax.swing.JTextField();
        tituloCliente1 = new javax.swing.JLabel();
        nombreCliente1 = new javax.swing.JLabel();
        DNICliente1 = new javax.swing.JLabel();
        direccionCliente1 = new javax.swing.JLabel();
        fechaCliente1 = new javax.swing.JLabel();
        telefonoCliente1 = new javax.swing.JLabel();
        botonAñadirCliente = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        panelEmpleado = new javax.swing.JPanel();
        textFieldTelefonoEmpleado = new javax.swing.JTextField();
        puestoEmpleado = new javax.swing.JLabel();
        textFieldNombreEmpleado = new javax.swing.JTextField();
        textFieldDNIEmpleado = new javax.swing.JTextField();
        textFieldPuestoEmpleado = new javax.swing.JTextField();
        textFieldDireccionEmpleado = new javax.swing.JTextField();
        textFieldSalarioEmpleado = new javax.swing.JTextField();
        salarioEmpleado = new javax.swing.JLabel();
        contraseñaEmpleado = new javax.swing.JLabel();
        passwordFieldContraseñaEmpleado = new javax.swing.JPasswordField();
        tituloCliente2 = new javax.swing.JLabel();
        nombreCliente2 = new javax.swing.JLabel();
        DNICliente2 = new javax.swing.JLabel();
        direccionCliente2 = new javax.swing.JLabel();
        telefonoCliente2 = new javax.swing.JLabel();
        botonAñadirEmpleado = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        panelClases = new javax.swing.JPanel();
        textFieldEmpleadoACargoClase = new javax.swing.JTextField();
        empleadoACargoClase = new javax.swing.JLabel();
        textFieldNombreClase = new javax.swing.JTextField();
        textFieldFechaClase = new javax.swing.JTextField();
        checkBoxRealizoClase = new javax.swing.JCheckBox();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        botonAñadirClase = new javax.swing.JLabel();
        tituloCliente3 = new javax.swing.JLabel();
        nombreCliente3 = new javax.swing.JLabel();
        DNICliente3 = new javax.swing.JLabel();
        panelAsistentes = new javax.swing.JPanel();
        textFieldIDClaseAsistente = new javax.swing.JTextField();
        textFieldIDClienteAsistente = new javax.swing.JTextField();
        tituloCliente4 = new javax.swing.JLabel();
        nombreCliente4 = new javax.swing.JLabel();
        DNICliente4 = new javax.swing.JLabel();
        botonAñadirAsistente = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        panelMaterial = new javax.swing.JPanel();
        textFieldNombreMaterial = new javax.swing.JTextField();
        textFieldCantidadMaterial = new javax.swing.JTextField();
        tituloCliente5 = new javax.swing.JLabel();
        nombreCliente5 = new javax.swing.JLabel();
        DNICliente5 = new javax.swing.JLabel();
        botonAñadirMaterial = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        panelMaterialUsado = new javax.swing.JPanel();
        textFieldIDClaseMaterialUsado = new javax.swing.JTextField();
        textFieldIDMaterialMaterialUsado = new javax.swing.JTextField();
        IDMaterialMaterialUsado = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        botonAñadirMaterialUsado = new javax.swing.JLabel();
        DNICliente6 = new javax.swing.JLabel();
        nombreCliente6 = new javax.swing.JLabel();
        tituloCliente6 = new javax.swing.JLabel();
        modelosTablas = new javax.swing.JDialog();
        jScrollPane1 = new javax.swing.JScrollPane();
        modeloEmpleado = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        modeloCliente = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        modeloPersona = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        modeloClase = new javax.swing.JTable();
        jScrollPane5 = new javax.swing.JScrollPane();
        modeloAsistentes = new javax.swing.JTable();
        jScrollPane6 = new javax.swing.JScrollPane();
        modeloMaterialClase = new javax.swing.JTable();
        jScrollPane7 = new javax.swing.JScrollPane();
        modeloMaterial = new javax.swing.JTable();
        jScrollPane8 = new javax.swing.JScrollPane();
        modeloNombreEmpleadosSalario = new javax.swing.JTable();
        jScrollPane9 = new javax.swing.JScrollPane();
        modeloNombreClasesMateriales = new javax.swing.JTable();
        errorSeleccionarTabla = new javax.swing.JDialog();
        jLabel39 = new javax.swing.JLabel();
        errorBlancoOFormatoIncorrecto = new javax.swing.JDialog();
        jLabel43 = new javax.swing.JLabel();
        textoBienvenida = new javax.swing.JLabel();
        botonCerrar = new javax.swing.JLabel();
        areaInicioSesion = new javax.swing.JPanel();
        labelIniciarSesion = new javax.swing.JLabel();
        labelIdEmpleado = new javax.swing.JLabel();
        textFieldIDInicioSesion = new javax.swing.JTextField();
        labelContraseña = new javax.swing.JLabel();
        passwordFieldContraseñaInicioSesion = new javax.swing.JPasswordField();
        labelBotonEntrar = new javax.swing.JLabel();
        bordePantallaInicio1 = new javax.swing.JLabel();
        bordePantallaInicio = new javax.swing.JLabel();

        pantallaPrincipal.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        pantallaPrincipal.setTitle("Gestor base de datos");
        pantallaPrincipal.setBackground(new java.awt.Color(102, 102, 102));
        pantallaPrincipal.setMaximumSize(new java.awt.Dimension(1024, 768));
        pantallaPrincipal.setMinimumSize(new java.awt.Dimension(1024, 768));
        pantallaPrincipal.setResizable(false);
        pantallaPrincipal.setSize(new java.awt.Dimension(1024, 768));
        pantallaPrincipal.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                pantallaPrincipalWindowClosed(evt);
            }
        });
        pantallaPrincipal.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        selectorPrincipal.setBackground(new java.awt.Color(204, 204, 204));
        selectorPrincipal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 0));
        selectorPrincipal.setFont(new java.awt.Font("Impact", 0, 12)); // NOI18N
        selectorPrincipal.setPreferredSize(new java.awt.Dimension(280, 190));

        panelPrincipalTablaDatos.setBackground(new java.awt.Color(204, 204, 204));
        panelPrincipalTablaDatos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 0));
        panelPrincipalTablaDatos.setPreferredSize(new java.awt.Dimension(280, 190));
        panelPrincipalTablaDatos.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tablaDatos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        scrollPaneTablaDatos.setViewportView(tablaDatos);

        panelPrincipalTablaDatos.add(scrollPaneTablaDatos, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 540, 480));

        tituloBorrarLinea.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        tituloBorrarLinea.setText("Borrar");
        panelPrincipalTablaDatos.add(tituloBorrarLinea, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 350, -1, -1));

        buscarID.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        buscarID.setText("<html><p align=\"center\">Buscar</p></html>");
        panelPrincipalTablaDatos.add(buscarID, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 140, -1, -1));

        comboBoxElementoABuscar.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar...", "PERSONA", "CLIENTE", "EMPLEADO", "MATERIAL", "CLASE", "ASISTENTES", "MATERIAL DE CLASES" }));
        panelPrincipalTablaDatos.add(comboBoxElementoABuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 140, 230, 30));

        IDABuscar.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        IDABuscar.setText("con la ID:");
        panelPrincipalTablaDatos.add(IDABuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 190, -1, -1));
        panelPrincipalTablaDatos.add(textFieldIDABuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 190, 230, 30));
        panelPrincipalTablaDatos.add(textFieldIDABorrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 400, 230, 30));

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar...", "Persona", "Cliente", "Empleado", "Material" }));
        panelPrincipalTablaDatos.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 350, 230, 30));

        jLabel38.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        jLabel38.setText("con la ID:");
        panelPrincipalTablaDatos.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 400, -1, -1));

        verDatosEmpleados.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonEmpleadosCuadrado.png"))); // NOI18N
        verDatosEmpleados.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        verDatosEmpleados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                verDatosEmpleadosMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                verDatosEmpleadosMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                verDatosEmpleadosMouseExited(evt);
            }
        });
        panelPrincipalTablaDatos.add(verDatosEmpleados, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 20, -1, -1));

        verDatosPersonas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonPersonasCuadrado.png"))); // NOI18N
        verDatosPersonas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        verDatosPersonas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                verDatosPersonasMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                verDatosPersonasMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                verDatosPersonasMouseExited(evt);
            }
        });
        panelPrincipalTablaDatos.add(verDatosPersonas, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 20, -1, -1));

        verDatosMaterial.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonMaterialCuadrado.png"))); // NOI18N
        verDatosMaterial.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        verDatosMaterial.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                verDatosMaterialMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                verDatosMaterialMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                verDatosMaterialMouseExited(evt);
            }
        });
        panelPrincipalTablaDatos.add(verDatosMaterial, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 20, -1, -1));

        verDatosClases.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonClasesCuadrado.png"))); // NOI18N
        verDatosClases.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        verDatosClases.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                verDatosClasesMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                verDatosClasesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                verDatosClasesMouseExited(evt);
            }
        });
        panelPrincipalTablaDatos.add(verDatosClases, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 20, -1, -1));

        verDatosAsistentes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonAsistentesCuadrado.png"))); // NOI18N
        verDatosAsistentes.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        verDatosAsistentes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                verDatosAsistentesMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                verDatosAsistentesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                verDatosAsistentesMouseExited(evt);
            }
        });
        panelPrincipalTablaDatos.add(verDatosAsistentes, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 20, -1, -1));

        verDatosMaterialUsado.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonMaterialUsadoCuadrado.png"))); // NOI18N
        verDatosMaterialUsado.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        verDatosMaterialUsado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                verDatosMaterialUsadoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                verDatosMaterialUsadoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                verDatosMaterialUsadoMouseExited(evt);
            }
        });
        panelPrincipalTablaDatos.add(verDatosMaterialUsado, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 20, -1, -1));

        verDatosClientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonClientesCuadrado.png"))); // NOI18N
        verDatosClientes.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        verDatosClientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                verDatosClientesMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                verDatosClientesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                verDatosClientesMouseExited(evt);
            }
        });
        panelPrincipalTablaDatos.add(verDatosClientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 20, -1, -1));

        botonBorrarLinea.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonBorrarCuadrado.png"))); // NOI18N
        botonBorrarLinea.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonBorrarLinea.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonBorrarLineaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonBorrarLineaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonBorrarLineaMouseExited(evt);
            }
        });
        panelPrincipalTablaDatos.add(botonBorrarLinea, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 450, -1, 120));

        jLabel40.setBackground(new java.awt.Color(170, 170, 170));
        jLabel40.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/fondoBotones.png"))); // NOI18N
        panelPrincipalTablaDatos.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 970, 90));

        botonBuscarConID.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonBuscar.png"))); // NOI18N
        botonBuscarConID.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonBuscarConID.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonBuscarConIDMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonBuscarConIDMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonBuscarConIDMouseExited(evt);
            }
        });
        panelPrincipalTablaDatos.add(botonBuscarConID, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 240, -1, 50));

        jLabel41.setBackground(new java.awt.Color(170, 170, 170));
        jLabel41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/fondoBorrar.png"))); // NOI18N
        panelPrincipalTablaDatos.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 310, 460, 280));

        jLabel42.setBackground(new java.awt.Color(170, 170, 170));
        jLabel42.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/fondoBuscar.png"))); // NOI18N
        panelPrincipalTablaDatos.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 110, 420, 200));

        jLabel45.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/logoEsloganMain.png"))); // NOI18N
        panelPrincipalTablaDatos.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 590, 480, 80));

        jLabel44.setBackground(new java.awt.Color(170, 170, 170));
        jLabel44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/fondoLogo.png"))); // NOI18N
        panelPrincipalTablaDatos.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 600, 480, 80));

        botonPersonasOrdenNombre.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonPersonasOrdenNombre.png"))); // NOI18N
        botonPersonasOrdenNombre.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonPersonasOrdenNombre.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonPersonasOrdenNombreMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonPersonasOrdenNombreMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonPersonasOrdenNombreMouseExited(evt);
            }
        });
        panelPrincipalTablaDatos.add(botonPersonasOrdenNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 600, 130, 80));

        botonClasesRealizadas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonClasesRealizadas.png"))); // NOI18N
        botonClasesRealizadas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonClasesRealizadas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonClasesRealizadasMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonClasesRealizadasMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonClasesRealizadasMouseExited(evt);
            }
        });
        panelPrincipalTablaDatos.add(botonClasesRealizadas, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 600, 130, 80));

        botonNombreClasesMateriales.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonNombreClasesMateriales.png"))); // NOI18N
        botonNombreClasesMateriales.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonNombreClasesMateriales.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonNombreClasesMaterialesMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonNombreClasesMaterialesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonNombreClasesMaterialesMouseExited(evt);
            }
        });
        panelPrincipalTablaDatos.add(botonNombreClasesMateriales, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 600, 130, 80));

        botonNombreEmpleadosSalario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonNombreEmpleadosSalario.png"))); // NOI18N
        botonNombreEmpleadosSalario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonNombreEmpleadosSalario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonNombreEmpleadosSalarioMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonNombreEmpleadosSalarioMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonNombreEmpleadosSalarioMouseExited(evt);
            }
        });
        panelPrincipalTablaDatos.add(botonNombreEmpleadosSalario, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 600, 130, 80));

        selectorPrincipal.addTab("Ver datos", null, panelPrincipalTablaDatos, "");

        panelPrincipalInsertarDatos.setBackground(new java.awt.Color(204, 204, 204));
        panelPrincipalInsertarDatos.setPreferredSize(new java.awt.Dimension(280, 190));
        panelPrincipalInsertarDatos.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        selectorInsertarDatos.setBackground(new java.awt.Color(153, 153, 153));
        selectorInsertarDatos.setTabPlacement(javax.swing.JTabbedPane.LEFT);

        panelCliente.setBackground(new java.awt.Color(153, 153, 153));
        panelCliente.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        panelCliente.add(textFieldNombreCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 160, 200, 30));
        panelCliente.add(textFieldDNICliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 220, 200, 30));
        panelCliente.add(textFieldDireccionCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 280, 200, 30));
        panelCliente.add(textFieldFechaCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 340, 200, 30));
        panelCliente.add(textFieldTelefonoCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 400, 200, 30));

        tituloCliente1.setFont(new java.awt.Font("Impact", 0, 60)); // NOI18N
        tituloCliente1.setText("<html><p align=\"center\">AÑADIR UN CLIENTE</p></html>");
        panelCliente.add(tituloCliente1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, 450, -1));

        nombreCliente1.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        nombreCliente1.setText("NOMBRE COMPLETO");
        panelCliente.add(nombreCliente1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 160, -1, -1));

        DNICliente1.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        DNICliente1.setText("DNI / NIF");
        panelCliente.add(DNICliente1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 220, -1, -1));

        direccionCliente1.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        direccionCliente1.setText("DIRECCION");
        panelCliente.add(direccionCliente1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 280, -1, -1));

        fechaCliente1.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        fechaCliente1.setText("FECHA DE INSCRIPCION");
        panelCliente.add(fechaCliente1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 340, -1, -1));

        telefonoCliente1.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        telefonoCliente1.setText("TELÉFONO");
        panelCliente.add(telefonoCliente1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 400, -1, -1));

        botonAñadirCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonAñadir.png"))); // NOI18N
        botonAñadirCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonAñadirCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonAñadirClienteMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonAñadirClienteMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonAñadirClienteMouseExited(evt);
            }
        });
        panelCliente.add(botonAñadirCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 470, 280, 80));

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setOpaque(true);
        panelCliente.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 676, 680, 7));

        jLabel3.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        jLabel3.setText("PROGRAMA TU ENTRENAMIENTO");
        panelCliente.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 580, 290, 70));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setOpaque(true);
        panelCliente.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 580, 870, 70));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/bannerVertical.png"))); // NOI18N
        panelCliente.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(637, -5, 200, 700));

        jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        jLabel4.setOpaque(true);
        panelCliente.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 650, 870, 15));

        jLabel5.setBackground(new java.awt.Color(255, 0, 0));
        jLabel5.setToolTipText("");
        jLabel5.setOpaque(true);
        panelCliente.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 665, 870, 32));

        selectorInsertarDatos.addTab("Cliente", panelCliente);

        panelEmpleado.setBackground(new java.awt.Color(153, 153, 153));
        panelEmpleado.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        panelEmpleado.add(textFieldTelefonoEmpleado, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 280, 240, 30));

        puestoEmpleado.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        puestoEmpleado.setText("PUESTO");
        panelEmpleado.add(puestoEmpleado, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 320, -1, -1));
        panelEmpleado.add(textFieldNombreEmpleado, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 160, 240, 30));
        panelEmpleado.add(textFieldDNIEmpleado, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 200, 240, 30));
        panelEmpleado.add(textFieldPuestoEmpleado, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 320, 240, 30));
        panelEmpleado.add(textFieldDireccionEmpleado, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 240, 240, 30));
        panelEmpleado.add(textFieldSalarioEmpleado, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 360, 240, 30));

        salarioEmpleado.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        salarioEmpleado.setText("SALARIO");
        panelEmpleado.add(salarioEmpleado, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 360, -1, -1));

        contraseñaEmpleado.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        contraseñaEmpleado.setText("CONTRASEÑA");
        panelEmpleado.add(contraseñaEmpleado, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 400, -1, -1));
        panelEmpleado.add(passwordFieldContraseñaEmpleado, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 400, 240, 30));

        tituloCliente2.setFont(new java.awt.Font("Impact", 0, 60)); // NOI18N
        tituloCliente2.setText("<html><p align=\"center\">AÑADIR UN EMPLEADO</p></html>");
        panelEmpleado.add(tituloCliente2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 50, 510, -1));

        nombreCliente2.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        nombreCliente2.setText("NOMBRE COMPLETO");
        panelEmpleado.add(nombreCliente2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 160, -1, -1));

        DNICliente2.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        DNICliente2.setText("DNI / NIF");
        panelEmpleado.add(DNICliente2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 200, -1, -1));

        direccionCliente2.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        direccionCliente2.setText("DIRECCION");
        panelEmpleado.add(direccionCliente2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 240, -1, -1));

        telefonoCliente2.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        telefonoCliente2.setText("TELÉFONO");
        panelEmpleado.add(telefonoCliente2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 280, -1, -1));

        botonAñadirEmpleado.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonAñadir.png"))); // NOI18N
        botonAñadirEmpleado.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonAñadirEmpleado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonAñadirEmpleadoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonAñadirEmpleadoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonAñadirEmpleadoMouseExited(evt);
            }
        });
        panelEmpleado.add(botonAñadirEmpleado, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 470, 280, 80));

        jLabel7.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        jLabel7.setText("PROGRAMA TU ENTRENAMIENTO");
        panelEmpleado.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 580, 290, 70));

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setOpaque(true);
        panelEmpleado.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 580, 870, 70));

        jLabel9.setBackground(new java.awt.Color(0, 0, 0));
        jLabel9.setOpaque(true);
        panelEmpleado.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 650, 870, 15));

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setOpaque(true);
        panelEmpleado.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 676, 680, 7));

        jLabel11.setBackground(new java.awt.Color(255, 0, 0));
        jLabel11.setToolTipText("");
        jLabel11.setOpaque(true);
        panelEmpleado.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 665, 870, 32));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/bannerVertical.png"))); // NOI18N
        panelEmpleado.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(637, -5, 200, 700));

        selectorInsertarDatos.addTab("Empleado", panelEmpleado);

        panelClases.setBackground(new java.awt.Color(153, 153, 153));
        panelClases.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        panelClases.add(textFieldEmpleadoACargoClase, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 310, 230, 30));

        empleadoACargoClase.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        empleadoACargoClase.setText("EMPLEADO A CARGO");
        panelClases.add(empleadoACargoClase, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 310, 190, -1));
        panelClases.add(textFieldNombreClase, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 190, 230, 30));
        panelClases.add(textFieldFechaClase, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 250, 230, 30));

        checkBoxRealizoClase.setBackground(new java.awt.Color(153, 153, 153));
        checkBoxRealizoClase.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        checkBoxRealizoClase.setText("¿SE REALIZÓ?");
        panelClases.add(checkBoxRealizoClase, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 390, 160, 30));

        jLabel13.setBackground(new java.awt.Color(255, 255, 255));
        jLabel13.setOpaque(true);
        panelClases.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 676, 680, 7));

        jLabel14.setBackground(new java.awt.Color(255, 0, 0));
        jLabel14.setToolTipText("");
        jLabel14.setOpaque(true);
        panelClases.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 665, 870, 32));

        jLabel15.setBackground(new java.awt.Color(0, 0, 0));
        jLabel15.setOpaque(true);
        panelClases.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 650, 870, 15));

        jLabel16.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        jLabel16.setText("PROGRAMA TU ENTRENAMIENTO");
        panelClases.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 580, 290, 70));

        jLabel17.setBackground(new java.awt.Color(255, 255, 255));
        jLabel17.setOpaque(true);
        panelClases.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 580, 870, 70));

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/bannerVertical.png"))); // NOI18N
        panelClases.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(637, -5, 200, 700));

        botonAñadirClase.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonAñadir.png"))); // NOI18N
        botonAñadirClase.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonAñadirClase.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonAñadirClaseMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonAñadirClaseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonAñadirClaseMouseExited(evt);
            }
        });
        panelClases.add(botonAñadirClase, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 470, 280, 80));

        tituloCliente3.setFont(new java.awt.Font("Impact", 0, 60)); // NOI18N
        tituloCliente3.setText("<html><p align=\"center\">AÑADIR UNA CLASE</p></html>");
        panelClases.add(tituloCliente3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, 450, -1));

        nombreCliente3.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        nombreCliente3.setText("NOMBRE");
        panelClases.add(nombreCliente3, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 190, -1, -1));

        DNICliente3.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        DNICliente3.setText("FECHA Y HORA");
        panelClases.add(DNICliente3, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 250, -1, -1));

        selectorInsertarDatos.addTab("Clases", panelClases);

        panelAsistentes.setBackground(new java.awt.Color(153, 153, 153));
        panelAsistentes.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        panelAsistentes.add(textFieldIDClaseAsistente, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 260, 230, 30));
        panelAsistentes.add(textFieldIDClienteAsistente, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 320, 230, 30));

        tituloCliente4.setFont(new java.awt.Font("Impact", 0, 60)); // NOI18N
        tituloCliente4.setText("<html><p align=\"center\">AÑADIR UN ASISTENTE</p></html>");
        panelAsistentes.add(tituloCliente4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 520, -1));

        nombreCliente4.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        nombreCliente4.setText("ID DE LA CLASE");
        panelAsistentes.add(nombreCliente4, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 260, -1, -1));

        DNICliente4.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        DNICliente4.setText("ID DEL CLIENTE");
        panelAsistentes.add(DNICliente4, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 320, -1, -1));

        botonAñadirAsistente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonAñadir.png"))); // NOI18N
        botonAñadirAsistente.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonAñadirAsistente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonAñadirAsistenteMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonAñadirAsistenteMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonAñadirAsistenteMouseExited(evt);
            }
        });
        panelAsistentes.add(botonAñadirAsistente, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 470, 280, 80));

        jLabel19.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        jLabel19.setText("PROGRAMA TU ENTRENAMIENTO");
        panelAsistentes.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 580, 290, 70));

        jLabel20.setBackground(new java.awt.Color(255, 255, 255));
        jLabel20.setOpaque(true);
        panelAsistentes.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 580, 870, 70));

        jLabel25.setBackground(new java.awt.Color(255, 255, 255));
        jLabel25.setOpaque(true);
        panelAsistentes.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 676, 680, 7));

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/bannerVertical.png"))); // NOI18N
        panelAsistentes.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(637, -5, 200, 700));

        jLabel22.setBackground(new java.awt.Color(0, 0, 0));
        jLabel22.setOpaque(true);
        panelAsistentes.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 650, 870, 15));

        jLabel23.setBackground(new java.awt.Color(255, 0, 0));
        jLabel23.setToolTipText("");
        jLabel23.setOpaque(true);
        panelAsistentes.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 665, 870, 32));

        jLabel24.setBackground(new java.awt.Color(255, 255, 255));
        jLabel24.setOpaque(true);
        panelAsistentes.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 676, 680, 7));

        selectorInsertarDatos.addTab("Asistentes a clases", panelAsistentes);

        panelMaterial.setBackground(new java.awt.Color(153, 153, 153));
        panelMaterial.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        panelMaterial.add(textFieldNombreMaterial, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 260, 230, 30));
        panelMaterial.add(textFieldCantidadMaterial, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 320, 230, 30));

        tituloCliente5.setFont(new java.awt.Font("Impact", 0, 60)); // NOI18N
        tituloCliente5.setText("<html><p align=\"center\">AÑADIR MATERIAL</p></html>");
        panelMaterial.add(tituloCliente5, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 50, 520, -1));

        nombreCliente5.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        nombreCliente5.setText("NOMBRE");
        panelMaterial.add(nombreCliente5, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 260, -1, -1));

        DNICliente5.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        DNICliente5.setText("CANTIDAD");
        panelMaterial.add(DNICliente5, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 320, -1, -1));

        botonAñadirMaterial.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonAñadir.png"))); // NOI18N
        botonAñadirMaterial.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonAñadirMaterial.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonAñadirMaterialMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonAñadirMaterialMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonAñadirMaterialMouseExited(evt);
            }
        });
        panelMaterial.add(botonAñadirMaterial, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 470, 280, 80));

        jLabel28.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        jLabel28.setText("PROGRAMA TU ENTRENAMIENTO");
        panelMaterial.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 580, 290, 70));

        jLabel27.setBackground(new java.awt.Color(255, 255, 255));
        jLabel27.setOpaque(true);
        panelMaterial.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 580, 870, 70));

        jLabel29.setBackground(new java.awt.Color(0, 0, 0));
        jLabel29.setOpaque(true);
        panelMaterial.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 650, 870, 15));

        jLabel31.setBackground(new java.awt.Color(255, 255, 255));
        jLabel31.setOpaque(true);
        panelMaterial.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 676, 680, 7));

        jLabel30.setBackground(new java.awt.Color(255, 0, 0));
        jLabel30.setToolTipText("");
        jLabel30.setOpaque(true);
        panelMaterial.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 665, 870, 32));

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/bannerVertical.png"))); // NOI18N
        panelMaterial.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(637, -5, 200, 700));

        selectorInsertarDatos.addTab("Material", panelMaterial);

        panelMaterialUsado.setBackground(new java.awt.Color(153, 153, 153));
        panelMaterialUsado.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        panelMaterialUsado.add(textFieldIDClaseMaterialUsado, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 260, 170, 30));
        panelMaterialUsado.add(textFieldIDMaterialMaterialUsado, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 320, 170, 30));

        IDMaterialMaterialUsado.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        panelMaterialUsado.add(IDMaterialMaterialUsado, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 330, -1, -1));

        jLabel33.setBackground(new java.awt.Color(255, 255, 255));
        jLabel33.setOpaque(true);
        panelMaterialUsado.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 676, 680, 7));

        jLabel32.setBackground(new java.awt.Color(255, 0, 0));
        jLabel32.setToolTipText("");
        jLabel32.setOpaque(true);
        panelMaterialUsado.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 665, 870, 32));

        jLabel34.setBackground(new java.awt.Color(0, 0, 0));
        jLabel34.setOpaque(true);
        panelMaterialUsado.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 650, 870, 15));

        jLabel35.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        jLabel35.setText("PROGRAMA TU ENTRENAMIENTO");
        panelMaterialUsado.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 580, 290, 70));

        jLabel37.setBackground(new java.awt.Color(255, 255, 255));
        jLabel37.setOpaque(true);
        panelMaterialUsado.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 580, 870, 70));

        jLabel36.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/bannerVertical.png"))); // NOI18N
        panelMaterialUsado.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(637, -5, 200, 700));

        botonAñadirMaterialUsado.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonAñadir.png"))); // NOI18N
        botonAñadirMaterialUsado.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonAñadirMaterialUsado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonAñadirMaterialUsadoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonAñadirMaterialUsadoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonAñadirMaterialUsadoMouseExited(evt);
            }
        });
        panelMaterialUsado.add(botonAñadirMaterialUsado, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 470, 280, 80));

        DNICliente6.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        DNICliente6.setText("ID DEL MATERIAL");
        panelMaterialUsado.add(DNICliente6, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 320, -1, -1));

        nombreCliente6.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        nombreCliente6.setText("ID DE LA CLASE");
        panelMaterialUsado.add(nombreCliente6, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 260, -1, -1));

        tituloCliente6.setFont(new java.awt.Font("Impact", 0, 60)); // NOI18N
        tituloCliente6.setText("<html><p align=\"center\">ANOTAR MATERIAL USADO</p></html>");
        panelMaterialUsado.add(tituloCliente6, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 50, 520, -1));

        selectorInsertarDatos.addTab("Material usado en clases", panelMaterialUsado);

        panelPrincipalInsertarDatos.add(selectorInsertarDatos, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1030, 740));

        selectorPrincipal.addTab("Insertar datos", panelPrincipalInsertarDatos);

        pantallaPrincipal.getContentPane().add(selectorPrincipal, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1024, 768));
        selectorPrincipal.getAccessibleContext().setAccessibleName("pane");

        pantallaPrincipal.getAccessibleContext().setAccessibleParent(null);

        modelosTablas.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        modeloEmpleado.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Salario", "Puesto", "Contraseña"
            }
        ));
        jScrollPane1.setViewportView(modeloEmpleado);

        modelosTablas.getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 450, 70));

        modeloCliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id ", "Fecha de inscripción"
            }
        ));
        jScrollPane2.setViewportView(modeloCliente);

        modelosTablas.getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, -1, 70));

        modeloPersona.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Nombre", "DNI", "Dirección", "Teléfono"
            }
        ));
        jScrollPane3.setViewportView(modeloPersona);

        modelosTablas.getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, -1, 70));

        modeloClase.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Nombre", "Fecha y hora", "Realizado", "Empleado a cargo"
            }
        ));
        jScrollPane4.setViewportView(modeloClase);

        modelosTablas.getContentPane().add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, -1, 80));

        modeloAsistentes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id de la clase", "Id del cliente"
            }
        ));
        jScrollPane5.setViewportView(modeloAsistentes);

        modelosTablas.getContentPane().add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, -1, 80));

        modeloMaterialClase.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id de la clase", "Id del equipamiento"
            }
        ));
        jScrollPane6.setViewportView(modeloMaterialClase);

        modelosTablas.getContentPane().add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 440, -1, 70));

        modeloMaterial.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Nombre"
            }
        ));
        jScrollPane7.setViewportView(modeloMaterial);

        modelosTablas.getContentPane().add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 520, -1, 70));

        modeloNombreEmpleadosSalario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Puesto", "Salario"
            }
        ));
        jScrollPane8.setViewportView(modeloNombreEmpleadosSalario);

        modelosTablas.getContentPane().add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 20, -1, 70));

        modeloNombreClasesMateriales.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre de la clase", "Nombre del material"
            }
        ));
        jScrollPane9.setViewportView(modeloNombreClasesMateriales);

        modelosTablas.getContentPane().add(jScrollPane9, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 100, -1, 70));

        errorSeleccionarTabla.setMinimumSize(new java.awt.Dimension(512, 384));
        errorSeleccionarTabla.setResizable(false);
        errorSeleccionarTabla.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel39.setFont(new java.awt.Font("Impact", 0, 36)); // NOI18N
        jLabel39.setText("<html><p align=\"center\">DEBES SELECCIONAR UNA TABLA DE LA QUE BORRAR / CONSULTAR</p></html>");
        jLabel39.setMaximumSize(new java.awt.Dimension(512, 384));
        jLabel39.setMinimumSize(new java.awt.Dimension(512, 384));
        jLabel39.setPreferredSize(new java.awt.Dimension(512, 384));
        errorSeleccionarTabla.getContentPane().add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(56, 92, 400, 200));

        errorBlancoOFormatoIncorrecto.setMinimumSize(new java.awt.Dimension(512, 384));
        errorBlancoOFormatoIncorrecto.setResizable(false);
        errorBlancoOFormatoIncorrecto.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel43.setFont(new java.awt.Font("Impact", 0, 36)); // NOI18N
        jLabel43.setText("<html><p align=\"center\">HAY ESPACIOS EN BLANCO O FORMATOS INCORRECTOS EN LOS CAMPOS A RELLENAR</p></html>");
        errorBlancoOFormatoIncorrecto.getContentPane().add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 520, 390));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Iniciar sesión");
        setIconImage(new javax.swing.ImageIcon(getClass().getResource("Fotos/iconoJGym.png")).getImage());
        setMaximumSize(new java.awt.Dimension(1024, 768));
        setMinimumSize(new java.awt.Dimension(1024, 768));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        textoBienvenida.setFont(new java.awt.Font("Impact", 1, 100)); // NOI18N
        textoBienvenida.setForeground(new java.awt.Color(255, 255, 255));
        textoBienvenida.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        textoBienvenida.setText("jGym");
        getContentPane().add(textoBienvenida, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 50, 290, -1));

        botonCerrar.setFont(new java.awt.Font("Segoe UI", 3, 100)); // NOI18N
        botonCerrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonCerrar.png"))); // NOI18N
        botonCerrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonCerrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonCerrarMouseClicked(evt);
            }
        });
        getContentPane().add(botonCerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 20, -1, 40));

        areaInicioSesion.setBackground(new java.awt.Color(0, 0, 101));
        areaInicioSesion.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        labelIniciarSesion.setFont(new java.awt.Font("Copperplate Gothic Bold", 1, 26)); // NOI18N
        labelIniciarSesion.setForeground(new java.awt.Color(255, 255, 255));
        labelIniciarSesion.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelIniciarSesion.setText("Iniciar sesión");
        areaInicioSesion.add(labelIniciarSesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 30, 250, -1));

        labelIdEmpleado.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelIdEmpleado.setForeground(new java.awt.Color(255, 255, 255));
        labelIdEmpleado.setText("ID de empleado:");
        areaInicioSesion.add(labelIdEmpleado, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, -1, -1));
        areaInicioSesion.add(textFieldIDInicioSesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 260, 30));

        labelContraseña.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelContraseña.setForeground(new java.awt.Color(255, 255, 255));
        labelContraseña.setText("Contraseña:");
        areaInicioSesion.add(labelContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, -1, -1));
        areaInicioSesion.add(passwordFieldContraseñaInicioSesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 260, 30));

        labelBotonEntrar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelBotonEntrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/botonEntrar.png"))); // NOI18N
        labelBotonEntrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        labelBotonEntrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                labelBotonEntrarMouseClicked(evt);
            }
        });
        areaInicioSesion.add(labelBotonEntrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 260, 150, 60));

        bordePantallaInicio1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 51), 4));
        areaInicioSesion.add(bordePantallaInicio1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 300, 350));

        getContentPane().add(areaInicioSesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(362, 230, 300, 350));

        bordePantallaInicio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto_final_jgym/Fotos/fondoPantallaInicioSesion.jpg"))); // NOI18N
        bordePantallaInicio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 51), 4));
        getContentPane().add(bordePantallaInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1024, 768));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonCerrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCerrarMouseClicked
        System.exit(0);
    }//GEN-LAST:event_botonCerrarMouseClicked

    private void labelBotonEntrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_labelBotonEntrarMouseClicked
        boolean comprobar = conexionjGym.comprobarUsuario(textFieldIDInicioSesion.getText(), passwordFieldContraseñaInicioSesion.getText());
        if (comprobar) {
            JOptionPane.showMessageDialog(
                    null,
                    "Ha iniciado sesión",
                    "Aviso",
                    JOptionPane.INFORMATION_MESSAGE);
            this.dispose();
            pantallaPrincipal.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(
                    null,
                    "El usuario y/o contraseña son incorrectos",
                    "Aviso",
                    JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_labelBotonEntrarMouseClicked

    private void pantallaPrincipalWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_pantallaPrincipalWindowClosed
        System.exit(0);
    }//GEN-LAST:event_pantallaPrincipalWindowClosed

    private void botonAñadirClienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAñadirClienteMouseClicked
        if ((textFieldNombreCliente.getText().equals("")) || (textFieldDNICliente.getText().equals("")) || (textFieldDireccionCliente.getText().equals("")) || (textFieldFechaCliente.getText().equals("")) || (textFieldTelefonoCliente.getText().equals(""))) {
            errorBlancoOFormatoIncorrecto.setVisible(true);
        } else {
            Cliente cliente = new Cliente();
            cliente.setNombre(textFieldNombreCliente.getText());
            cliente.setDNI(textFieldDNICliente.getText());
            cliente.setDireccion(textFieldDireccionCliente.getText());
            cliente.setDate(textFieldFechaCliente.getText());
            cliente.setTelefono(Integer.parseInt(textFieldTelefonoCliente.getText()));
            conexionjGym.meterCliente(cliente);
            conexionjGym.guardarArchivo("Cliente añadido");
        }
        borrarCamposCliente();
    }//GEN-LAST:event_botonAñadirClienteMouseClicked

    private void botonAñadirEmpleadoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAñadirEmpleadoMouseClicked
        if ((textFieldNombreEmpleado.getText().equals("")) || (textFieldDNIEmpleado.getText().equals("")) || (textFieldDireccionEmpleado.getText().equals("")) || (textFieldTelefonoEmpleado.getText().equals("")) || (textFieldPuestoEmpleado.getText().equals("")) || (textFieldSalarioEmpleado.getText().equals("")) || (passwordFieldContraseñaEmpleado.getText().equals(""))) {
            errorBlancoOFormatoIncorrecto.setVisible(true);
        } else {
            Empleado empleado = new Empleado();
            empleado.setNombre(textFieldNombreEmpleado.getText());
            empleado.setDNI(textFieldDNIEmpleado.getText());
            empleado.setDireccion(textFieldDireccionEmpleado.getText());
            empleado.setTelefono(Integer.parseInt(textFieldTelefonoEmpleado.getText()));
            empleado.setSalario(Double.parseDouble(textFieldSalarioEmpleado.getText()));
            empleado.setPuesto(textFieldPuestoEmpleado.getText());
            empleado.setContrasenya(passwordFieldContraseñaEmpleado.getText());
            conexionjGym.meterEmpleado(empleado);
            conexionjGym.guardarArchivo("Empleado añadido");
        }
        borrarCamposEmpleado();
    }//GEN-LAST:event_botonAñadirEmpleadoMouseClicked

    private void botonAñadirClaseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAñadirClaseMouseClicked
        if ((textFieldNombreClase.getText().equals("")) || (textFieldFechaClase.getText().equals("")) || (textFieldEmpleadoACargoClase.getText().equals(""))) {
            errorBlancoOFormatoIncorrecto.setVisible(true);
        } else {
            ClasesGym clasesGym = new ClasesGym();
            clasesGym.setFechaHora(textFieldFechaClase.getText());
            clasesGym.setIdPersona(Integer.parseInt(textFieldEmpleadoACargoClase.getText()));
            clasesGym.setNombre(textFieldNombreClase.getText());
            if (checkBoxRealizoClase.isSelected()) {
                clasesGym.setRealizado(1);
            } else {
                clasesGym.setRealizado(0);
            }
            conexionjGym.meterClase(clasesGym);
            conexionjGym.guardarArchivo("Clase añadido");
        }
        borrarCamposClase();
    }//GEN-LAST:event_botonAñadirClaseMouseClicked

    private void botonAñadirAsistenteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAñadirAsistenteMouseClicked
        if ((textFieldIDClaseAsistente.getText().equals("")) || (textFieldIDClienteAsistente.getText().equals(""))) {
            errorBlancoOFormatoIncorrecto.setVisible(true);
        } else {
            conexionjGym.meterAsistentes(Integer.parseInt(textFieldIDClaseAsistente.getText()), Integer.parseInt(textFieldIDClienteAsistente.getText()));
            conexionjGym.guardarArchivo("Asistente registrado");
        }
        borrarCamposAsistente();
    }//GEN-LAST:event_botonAñadirAsistenteMouseClicked

    private void botonAñadirMaterialMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAñadirMaterialMouseClicked
        if ((textFieldNombreMaterial.getText().equals("")) || (textFieldCantidadMaterial.getText().equals(""))) {
            errorBlancoOFormatoIncorrecto.setVisible(true);
        } else {
            Equipamiento equipamiento = new Equipamiento();
            equipamiento.setNombre(textFieldNombreMaterial.getText());
            conexionjGym.meterEquipamiento(equipamiento, Integer.parseInt(textFieldCantidadMaterial.getText()));
            conexionjGym.guardarArchivo("Material añadido");
        }
        borrarCamposMaterial();
    }//GEN-LAST:event_botonAñadirMaterialMouseClicked

    private void botonAñadirMaterialUsadoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAñadirMaterialUsadoMouseClicked
        if ((textFieldIDClaseMaterialUsado.getText().equals("")) || (textFieldIDMaterialMaterialUsado.getText().equals(""))) {
            errorBlancoOFormatoIncorrecto.setVisible(true);
        } else {
            conexionjGym.meterEquipamientoClase(Integer.parseInt(textFieldIDClaseMaterialUsado.getText()), Integer.parseInt(textFieldIDMaterialMaterialUsado.getText()));
            DefaultTableModel modelo = (DefaultTableModel) tablaDatos.getModel();
            conexionjGym.guardarArchivo("Material registrado en clase");
        }
        borrarCamposMaterialUsado();
    }//GEN-LAST:event_botonAñadirMaterialUsadoMouseClicked

    private void verDatosPersonasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosPersonasMouseClicked
        mostrarPersonas("%");
        conexionjGym.guardarArchivo("Consulta ver personas realizada");
    }//GEN-LAST:event_verDatosPersonasMouseClicked

    private void verDatosClientesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosClientesMouseClicked
        mostrarClientes("%");
        conexionjGym.guardarArchivo("Consulta ver clientes realizada");
    }//GEN-LAST:event_verDatosClientesMouseClicked

    private void verDatosEmpleadosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosEmpleadosMouseClicked
        mostrarEmpleados("%");
        conexionjGym.guardarArchivo("Consulta ver empleados realizada");
    }//GEN-LAST:event_verDatosEmpleadosMouseClicked

    private void verDatosMaterialMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosMaterialMouseClicked
        mostrarMaterial("%");
        conexionjGym.guardarArchivo("Consulta ver material realizada");
    }//GEN-LAST:event_verDatosMaterialMouseClicked

    private void verDatosClasesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosClasesMouseClicked
        mostrarClases("%");
        conexionjGym.guardarArchivo("Consulta ver clases realizada");
    }//GEN-LAST:event_verDatosClasesMouseClicked

    private void verDatosAsistentesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosAsistentesMouseClicked
        mostrarAsistentes("%");
        conexionjGym.guardarArchivo("Consulta ver asistentes a clases realizada");
    }//GEN-LAST:event_verDatosAsistentesMouseClicked

    private void verDatosMaterialUsadoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosMaterialUsadoMouseClicked
        mostrarEquipamientoClase("%");
        conexionjGym.guardarArchivo("Consulta ver material usado realizada");
    }//GEN-LAST:event_verDatosMaterialUsadoMouseClicked

    private void botonBorrarLineaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonBorrarLineaMouseClicked
        if (jComboBox1.getSelectedIndex() == 0) {
            errorSeleccionarTabla.setVisible(true);
        } else {
            switch (jComboBox1.getSelectedIndex()) {
                case 1: {
                    conexionjGym.borrarPersona(Integer.parseInt(textFieldIDABorrar.getText()));
                    mostrarPersonas("%");
                    conexionjGym.guardarArchivo("Persona borrada");
                    break;
                }
                case 2: {
                    conexionjGym.borrarCliente(Integer.parseInt(textFieldIDABorrar.getText()));
                    mostrarClientes("%");
                    conexionjGym.guardarArchivo("Cliente borrado");
                    break;
                }
                case 3: {
                    conexionjGym.borrarEmpleado(Integer.parseInt(textFieldIDABorrar.getText()));
                    mostrarEmpleados("%");
                    conexionjGym.guardarArchivo("Empleado borrado");
                    break;
                }
                case 4: {
                    conexionjGym.borrarMaterial(Integer.parseInt(textFieldIDABorrar.getText()));
                    mostrarMaterial("%");
                    conexionjGym.guardarArchivo("Material borrado");
                    break;
                }
            }
        }
    }//GEN-LAST:event_botonBorrarLineaMouseClicked

    private void botonBuscarConIDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonBuscarConIDMouseClicked
        if (comboBoxElementoABuscar.getSelectedIndex() == 0) {
            errorSeleccionarTabla.setVisible(true);
        } else {
            switch (comboBoxElementoABuscar.getSelectedIndex()) {
                case 1: {
                    mostrarPersonas(textFieldIDABuscar.getText());
                    break;
                }
                case 2: {
                    mostrarClientes(textFieldIDABuscar.getText());
                    break;
                }
                case 3: {
                    mostrarEmpleados(textFieldIDABuscar.getText());
                    break;
                }
                case 4: {
                    mostrarMaterial(textFieldIDABuscar.getText());
                    break;
                }
                case 5: {
                    mostrarClases(textFieldIDABuscar.getText());
                    break;
                }
                case 6: {
                    mostrarAsistentes(textFieldIDABuscar.getText());
                    break;
                }
                case 7: {
                    mostrarEquipamientoClase(textFieldIDABuscar.getText());
                    break;
                }
            }
        }
    }//GEN-LAST:event_botonBuscarConIDMouseClicked

    private void botonBorrarLineaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonBorrarLineaMouseEntered
        cambiarIconoLabel("Fotos/botonBorrarCuadradoHover.png", botonBorrarLinea);
    }//GEN-LAST:event_botonBorrarLineaMouseEntered

    private void botonBorrarLineaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonBorrarLineaMouseExited
        cambiarIconoLabel("Fotos/botonBorrarCuadrado.png", botonBorrarLinea);
    }//GEN-LAST:event_botonBorrarLineaMouseExited

    private void botonBuscarConIDMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonBuscarConIDMouseEntered
        cambiarIconoLabel("Fotos/botonBuscarHover.png", botonBuscarConID);
    }//GEN-LAST:event_botonBuscarConIDMouseEntered

    private void botonBuscarConIDMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonBuscarConIDMouseExited
        cambiarIconoLabel("Fotos/botonBuscar.png", botonBuscarConID);
    }//GEN-LAST:event_botonBuscarConIDMouseExited

    private void verDatosPersonasMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosPersonasMouseEntered
        cambiarIconoLabel("Fotos/botonPersonasCuadradoHover.png", verDatosPersonas);
    }//GEN-LAST:event_verDatosPersonasMouseEntered

    private void verDatosPersonasMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosPersonasMouseExited
        cambiarIconoLabel("Fotos/botonPersonasCuadrado.png", verDatosPersonas);
    }//GEN-LAST:event_verDatosPersonasMouseExited

    private void verDatosClientesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosClientesMouseEntered
        cambiarIconoLabel("Fotos/botonClientesCuadradoHover.png", verDatosClientes);
    }//GEN-LAST:event_verDatosClientesMouseEntered

    private void verDatosClientesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosClientesMouseExited
        cambiarIconoLabel("Fotos/botonClientesCuadrado.png", verDatosClientes);
    }//GEN-LAST:event_verDatosClientesMouseExited

    private void verDatosEmpleadosMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosEmpleadosMouseEntered
        cambiarIconoLabel("Fotos/botonEmpleadosCuadradoHover.png", verDatosEmpleados);
    }//GEN-LAST:event_verDatosEmpleadosMouseEntered

    private void verDatosEmpleadosMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosEmpleadosMouseExited
        cambiarIconoLabel("Fotos/botonEmpleadosCuadrado.png", verDatosEmpleados);
    }//GEN-LAST:event_verDatosEmpleadosMouseExited

    private void verDatosMaterialMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosMaterialMouseEntered
        cambiarIconoLabel("Fotos/botonMaterialCuadradoHover.png", verDatosMaterial);
    }//GEN-LAST:event_verDatosMaterialMouseEntered

    private void verDatosMaterialMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosMaterialMouseExited
        cambiarIconoLabel("Fotos/botonMaterialCuadrado.png", verDatosMaterial);
    }//GEN-LAST:event_verDatosMaterialMouseExited

    private void verDatosClasesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosClasesMouseEntered
        cambiarIconoLabel("Fotos/botonClasesCuadradoHover.png", verDatosClases);
    }//GEN-LAST:event_verDatosClasesMouseEntered

    private void verDatosClasesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosClasesMouseExited
        cambiarIconoLabel("Fotos/botonClasesCuadrado.png", verDatosClases);
    }//GEN-LAST:event_verDatosClasesMouseExited

    private void verDatosAsistentesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosAsistentesMouseEntered
        cambiarIconoLabel("Fotos/botonAsistentesCuadradoHover.png", verDatosAsistentes);
    }//GEN-LAST:event_verDatosAsistentesMouseEntered

    private void verDatosAsistentesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosAsistentesMouseExited
        cambiarIconoLabel("Fotos/botonAsistentesCuadrado.png", verDatosAsistentes);
    }//GEN-LAST:event_verDatosAsistentesMouseExited

    private void verDatosMaterialUsadoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosMaterialUsadoMouseEntered
        cambiarIconoLabel("Fotos/botonMaterialUsadoCuadradoHover.png", verDatosMaterialUsado);
    }//GEN-LAST:event_verDatosMaterialUsadoMouseEntered

    private void verDatosMaterialUsadoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verDatosMaterialUsadoMouseExited
        cambiarIconoLabel("Fotos/botonMaterialUsadoCuadrado.png", verDatosMaterialUsado);
    }//GEN-LAST:event_verDatosMaterialUsadoMouseExited

    private void botonAñadirClienteMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAñadirClienteMouseEntered
        cambiarIconoLabel("Fotos/botonAñadirHover.png", botonAñadirCliente);
    }//GEN-LAST:event_botonAñadirClienteMouseEntered

    private void botonAñadirClienteMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAñadirClienteMouseExited
        cambiarIconoLabel("Fotos/botonAñadir.png", botonAñadirCliente);
    }//GEN-LAST:event_botonAñadirClienteMouseExited

    private void botonAñadirEmpleadoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAñadirEmpleadoMouseEntered
        cambiarIconoLabel("Fotos/botonAñadirHover.png", botonAñadirEmpleado);
    }//GEN-LAST:event_botonAñadirEmpleadoMouseEntered

    private void botonAñadirEmpleadoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAñadirEmpleadoMouseExited
        cambiarIconoLabel("Fotos/botonAñadir.png", botonAñadirEmpleado);
    }//GEN-LAST:event_botonAñadirEmpleadoMouseExited

    private void botonAñadirClaseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAñadirClaseMouseEntered
        cambiarIconoLabel("Fotos/botonAñadirHover.png", botonAñadirClase);
    }//GEN-LAST:event_botonAñadirClaseMouseEntered

    private void botonAñadirClaseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAñadirClaseMouseExited
        cambiarIconoLabel("Fotos/botonAñadir.png", botonAñadirClase);
    }//GEN-LAST:event_botonAñadirClaseMouseExited

    private void botonAñadirAsistenteMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAñadirAsistenteMouseEntered
        cambiarIconoLabel("Fotos/botonAñadirHover.png", botonAñadirAsistente);
    }//GEN-LAST:event_botonAñadirAsistenteMouseEntered

    private void botonAñadirAsistenteMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAñadirAsistenteMouseExited
        cambiarIconoLabel("Fotos/botonAñadir.png", botonAñadirAsistente);
    }//GEN-LAST:event_botonAñadirAsistenteMouseExited

    private void botonAñadirMaterialUsadoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAñadirMaterialUsadoMouseEntered
        cambiarIconoLabel("Fotos/botonAñadirHover.png", botonAñadirMaterialUsado);
    }//GEN-LAST:event_botonAñadirMaterialUsadoMouseEntered

    private void botonAñadirMaterialUsadoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAñadirMaterialUsadoMouseExited
        cambiarIconoLabel("Fotos/botonAñadir.png", botonAñadirMaterialUsado);
    }//GEN-LAST:event_botonAñadirMaterialUsadoMouseExited

    private void botonAñadirMaterialMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAñadirMaterialMouseEntered
        cambiarIconoLabel("Fotos/botonAñadirHover.png", botonAñadirMaterial);
    }//GEN-LAST:event_botonAñadirMaterialMouseEntered

    private void botonAñadirMaterialMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAñadirMaterialMouseExited
        cambiarIconoLabel("Fotos/botonAñadir.png", botonAñadirMaterial);
    }//GEN-LAST:event_botonAñadirMaterialMouseExited

    private void botonNombreEmpleadosSalarioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonNombreEmpleadosSalarioMouseEntered
        cambiarIconoLabel("Fotos/botonNombreEmpleadosSalarioHover.png", botonNombreEmpleadosSalario);
    }//GEN-LAST:event_botonNombreEmpleadosSalarioMouseEntered

    private void botonNombreEmpleadosSalarioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonNombreEmpleadosSalarioMouseExited
        cambiarIconoLabel("Fotos/botonNombreEmpleadosSalario.png", botonNombreEmpleadosSalario);
    }//GEN-LAST:event_botonNombreEmpleadosSalarioMouseExited

    private void botonPersonasOrdenNombreMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonPersonasOrdenNombreMouseEntered
        cambiarIconoLabel("Fotos/botonPersonasOrdenNombreHover.png", botonPersonasOrdenNombre);
    }//GEN-LAST:event_botonPersonasOrdenNombreMouseEntered

    private void botonPersonasOrdenNombreMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonPersonasOrdenNombreMouseExited
        cambiarIconoLabel("Fotos/botonPersonasOrdenNombre.png", botonPersonasOrdenNombre);
    }//GEN-LAST:event_botonPersonasOrdenNombreMouseExited

    private void botonClasesRealizadasMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonClasesRealizadasMouseEntered
        cambiarIconoLabel("Fotos/botonClasesRealizadasHover.png", botonClasesRealizadas);
    }//GEN-LAST:event_botonClasesRealizadasMouseEntered

    private void botonClasesRealizadasMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonClasesRealizadasMouseExited
        cambiarIconoLabel("Fotos/botonClasesRealizadas.png", botonClasesRealizadas);
    }//GEN-LAST:event_botonClasesRealizadasMouseExited

    private void botonNombreClasesMaterialesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonNombreClasesMaterialesMouseEntered
        cambiarIconoLabel("Fotos/botonNombreClasesMaterialesHover.png", botonNombreClasesMateriales);
    }//GEN-LAST:event_botonNombreClasesMaterialesMouseEntered

    private void botonNombreClasesMaterialesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonNombreClasesMaterialesMouseExited
        cambiarIconoLabel("Fotos/botonNombreClasesMateriales.png", botonNombreClasesMateriales);
    }//GEN-LAST:event_botonNombreClasesMaterialesMouseExited

    private void botonNombreEmpleadosSalarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonNombreEmpleadosSalarioMouseClicked
        mostrarNombreEmpleadosSalario();
    }//GEN-LAST:event_botonNombreEmpleadosSalarioMouseClicked

    private void botonPersonasOrdenNombreMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonPersonasOrdenNombreMouseClicked
        mostrarPersonasOrdenNombre();
    }//GEN-LAST:event_botonPersonasOrdenNombreMouseClicked

    private void botonClasesRealizadasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonClasesRealizadasMouseClicked
        mostrarClasesRealizadas();
    }//GEN-LAST:event_botonClasesRealizadasMouseClicked

    private void botonNombreClasesMaterialesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonNombreClasesMaterialesMouseClicked
        mostrarNombreClasesMateriales();
    }//GEN-LAST:event_botonNombreClasesMaterialesMouseClicked

    public void borrarTabla() {
        DefaultTableModel modelo = (DefaultTableModel) tablaDatos.getModel();
        int filas = Integer.parseInt(String.valueOf(tablaDatos.getRowCount()));
        for (int i = filas - 1; 0 <= i; i--) {
            modelo.removeRow(i);
        }
    }

    public void cambiarIconoLabel(String nombreIcono, JLabel label) {
        URL rutaIcono = getClass().getResource(nombreIcono);
        if (rutaIcono != null) {
            Icon icon = new ImageIcon(rutaIcono);
            label.setIcon(icon);
        }
    }

    public void mostrarPersonas(String id) {
        borrarTabla();
        tablaDatos.setModel(modeloPersona.getModel());
        ArrayList<Personas> listaPersonas = conexionjGym.sacarPersona(id);
        DefaultTableModel modeloTabla = (DefaultTableModel) tablaDatos.getModel();
        for (int i = 0; i < listaPersonas.size(); i++) {
            Object[] objPersonas = new Object[5];
            objPersonas[0] = listaPersonas.get(i).getIdPersona();
            objPersonas[1] = listaPersonas.get(i).getNombre();
            objPersonas[2] = listaPersonas.get(i).getDNI();
            objPersonas[3] = listaPersonas.get(i).getDireccion();
            objPersonas[4] = listaPersonas.get(i).getTelefono();
            modeloTabla.addRow(objPersonas);
        }
        tablaDatos.setModel(modeloTabla);
    }

    public void mostrarClientes(String id) {
        borrarTabla();
        tablaDatos.setModel(modeloCliente.getModel());
        ArrayList<Cliente> listaCliente = conexionjGym.sacarClientes(id);
        DefaultTableModel modeloTabla = (DefaultTableModel) tablaDatos.getModel();
        for (int i = 0; i < listaCliente.size(); i++) {
            Object[] objClientes = new Object[2];
            objClientes[0] = listaCliente.get(i).getIdPersona();
            objClientes[1] = listaCliente.get(i).getDate();
            modeloTabla.addRow(objClientes);
        }
        tablaDatos.setModel(modeloTabla);
    }

    public void mostrarEmpleados(String id) {
        borrarTabla();
        tablaDatos.setModel(modeloEmpleado.getModel());
        ArrayList<Empleado> listaEmpleado = conexionjGym.sacarEmpleados(id);
        DefaultTableModel modeloTabla = (DefaultTableModel) tablaDatos.getModel();
        for (int i = 0; i < listaEmpleado.size(); i++) {
            Object[] objEmpleados = new Object[4];
            objEmpleados[0] = listaEmpleado.get(i).getIdPersona();
            objEmpleados[1] = listaEmpleado.get(i).getSalario();
            objEmpleados[2] = listaEmpleado.get(i).getPuesto();
            objEmpleados[3] = listaEmpleado.get(i).getContrasenya();
            modeloTabla.addRow(objEmpleados);
        }
        tablaDatos.setModel(modeloTabla);
    }

    public void mostrarMaterial(String id) {
        borrarTabla();
        tablaDatos.setModel(modeloMaterial.getModel());
        ArrayList<Equipamiento> listaEquipamiento = conexionjGym.sacarEquipamiento(id);
        DefaultTableModel modeloTabla = (DefaultTableModel) tablaDatos.getModel();
        for (int i = 0; i < listaEquipamiento.size(); i++) {
            Object[] objEquipamiento = new Object[2];
            objEquipamiento[0] = listaEquipamiento.get(i).getIdEquipamiento();
            objEquipamiento[1] = listaEquipamiento.get(i).getNombre();
            modeloTabla.addRow(objEquipamiento);
        }
        tablaDatos.setModel(modeloTabla);
    }

    public void mostrarClases(String id) {
        borrarTabla();
        tablaDatos.setModel(modeloClase.getModel());
        ArrayList<ClasesGym> listaClases = conexionjGym.sacarClases(id);
        DefaultTableModel modeloTabla = (DefaultTableModel) tablaDatos.getModel();
        for (int i = 0; i < listaClases.size(); i++) {
            Object[] objClases = new Object[5];
            objClases[0] = listaClases.get(i).getIdClase();
            objClases[1] = listaClases.get(i).getNombre();
            objClases[2] = listaClases.get(i).getFechaHora();
            objClases[3] = listaClases.get(i).getRealizado();
            objClases[4] = listaClases.get(i).getIdPersona();
            modeloTabla.addRow(objClases);
        }
        tablaDatos.setModel(modeloTabla);
    }

    public void mostrarAsistentes(String id) {
        borrarTabla();
        tablaDatos.setModel(modeloAsistentes.getModel());
        DefaultTableModel modeloTabla = (DefaultTableModel) tablaDatos.getModel();
        ArrayList<Integer> listaClaseCliente = conexionjGym.sacarClaseCliente(id);
        for (int i = 0; i < listaClaseCliente.size() - 1; i += 2) {
            Object[] objAsistentes = new Object[2];
            objAsistentes[0] = listaClaseCliente.get(i);
            objAsistentes[1] = listaClaseCliente.get(i + 1);
            modeloTabla.addRow(objAsistentes);
        }
        tablaDatos.setModel(modeloTabla);
    }

    public void mostrarEquipamientoClase(String id) {
        borrarTabla();
        tablaDatos.setModel(modeloAsistentes.getModel());
        DefaultTableModel modeloTabla = (DefaultTableModel) tablaDatos.getModel();
        ArrayList<Integer> listaEquipamientoClase = conexionjGym.sacarEquipamientoClase(id);
        for (int i = 0; i < listaEquipamientoClase.size() - 1; i += 2) {
            Object[] objAsistentes = new Object[2];
            objAsistentes[0] = listaEquipamientoClase.get(i);
            objAsistentes[1] = listaEquipamientoClase.get(i + 1);
            modeloTabla.addRow(objAsistentes);
        }
        tablaDatos.setModel(modeloTabla);
    }

    public void mostrarNombreEmpleadosSalario() {
        borrarTabla();
        tablaDatos.setModel(modeloNombreEmpleadosSalario.getModel());
        DefaultTableModel modeloTabla = (DefaultTableModel) tablaDatos.getModel();
        ArrayList<Object> listaEquipamientoClase = conexionjGym.sacarNombreEmpleadosSalario();
        for (int i = 0; i < listaEquipamientoClase.size() - 1; i += 3) {
            Object[] objAsistentes = new Object[3];
            objAsistentes[0] = listaEquipamientoClase.get(i);
            objAsistentes[1] = listaEquipamientoClase.get(i + 1);
            objAsistentes[2] = listaEquipamientoClase.get(i + 2);
            modeloTabla.addRow(objAsistentes);
        }
        tablaDatos.setModel(modeloTabla);
    }

    public void mostrarPersonasOrdenNombre() {
        borrarTabla();
        tablaDatos.setModel(modeloPersona.getModel());
        DefaultTableModel modeloTabla = (DefaultTableModel) tablaDatos.getModel();
        ArrayList<Object> listaEquipamientoClase = conexionjGym.sacarPersonasOrdenNombre();
        for (int i = 0; i < listaEquipamientoClase.size() - 1; i += 5) {
            Object[] objAsistentes = new Object[5];
            objAsistentes[0] = listaEquipamientoClase.get(i);
            objAsistentes[1] = listaEquipamientoClase.get(i + 1);
            objAsistentes[2] = listaEquipamientoClase.get(i + 2);
            objAsistentes[3] = listaEquipamientoClase.get(i + 3);
            objAsistentes[4] = listaEquipamientoClase.get(i + 4);
            modeloTabla.addRow(objAsistentes);
        }
        tablaDatos.setModel(modeloTabla);
    }

    public void mostrarClasesRealizadas() {
        borrarTabla();
        tablaDatos.setModel(modeloClase.getModel());
        ArrayList<ClasesGym> listaClases = conexionjGym.sacarClasesRealizadas();
        DefaultTableModel modeloTabla = (DefaultTableModel) tablaDatos.getModel();
        for (int i = 0; i < listaClases.size(); i++) {
            Object[] objClases = new Object[5];
            objClases[0] = listaClases.get(i).getIdClase();
            objClases[1] = listaClases.get(i).getNombre();
            objClases[2] = listaClases.get(i).getFechaHora();
            objClases[3] = listaClases.get(i).getRealizado();
            objClases[4] = listaClases.get(i).getIdPersona();
            modeloTabla.addRow(objClases);
        }
        tablaDatos.setModel(modeloTabla);
    }

    public void mostrarNombreClasesMateriales() {
        borrarTabla();
        tablaDatos.setModel(modeloNombreClasesMateriales.getModel());
        DefaultTableModel modeloTabla = (DefaultTableModel) tablaDatos.getModel();
        ArrayList<String> listaEquipamientoClase = conexionjGym.sacarNombreClasesEquipamiento();
        for (int i = 0; i < listaEquipamientoClase.size() - 1; i += 2) {
            Object[] objAsistentes = new Object[2];
            objAsistentes[0] = listaEquipamientoClase.get(i);
            objAsistentes[1] = listaEquipamientoClase.get(i + 1);
            modeloTabla.addRow(objAsistentes);
        }
        tablaDatos.setModel(modeloTabla);
    }

    public void borrarCamposCliente() {
        textFieldNombreCliente.setText("");
        textFieldDNICliente.setText("");
        textFieldDireccionCliente.setText("");
        textFieldFechaCliente.setText("");
        textFieldTelefonoCliente.setText("");
    }

    public void borrarCamposEmpleado() {
        textFieldNombreEmpleado.setText("");
        textFieldDNIEmpleado.setText("");
        textFieldDireccionEmpleado.setText("");
        textFieldTelefonoEmpleado.setText("");
        textFieldPuestoEmpleado.setText("");
        textFieldSalarioEmpleado.setText("");
        passwordFieldContraseñaEmpleado.setText("");
    }

    public void borrarCamposClase() {
        textFieldNombreClase.setText("");
        textFieldFechaClase.setText("");
        textFieldEmpleadoACargoClase.setText("");
        checkBoxRealizoClase.setSelected(false);
    }

    public void borrarCamposAsistente() {
        textFieldIDClaseAsistente.setText("");
        textFieldIDClienteAsistente.setText("");
    }

    public void borrarCamposMaterial() {
        textFieldNombreMaterial.setText("");
        textFieldCantidadMaterial.setText("");
    }

    public void borrarCamposMaterialUsado() {
        textFieldIDClaseMaterialUsado.setText("");
        textFieldIDMaterialMaterialUsado.setText("");
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Pantalla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Pantalla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Pantalla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Pantalla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Pantalla().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel DNICliente1;
    private javax.swing.JLabel DNICliente2;
    private javax.swing.JLabel DNICliente3;
    private javax.swing.JLabel DNICliente4;
    private javax.swing.JLabel DNICliente5;
    private javax.swing.JLabel DNICliente6;
    private javax.swing.JLabel IDABuscar;
    private javax.swing.JLabel IDMaterialMaterialUsado;
    private javax.swing.JPanel areaInicioSesion;
    private javax.swing.JLabel bordePantallaInicio;
    private javax.swing.JLabel bordePantallaInicio1;
    private javax.swing.JLabel botonAñadirAsistente;
    private javax.swing.JLabel botonAñadirClase;
    private javax.swing.JLabel botonAñadirCliente;
    private javax.swing.JLabel botonAñadirEmpleado;
    private javax.swing.JLabel botonAñadirMaterial;
    private javax.swing.JLabel botonAñadirMaterialUsado;
    private javax.swing.JLabel botonBorrarLinea;
    private javax.swing.JLabel botonBuscarConID;
    private javax.swing.JLabel botonCerrar;
    private javax.swing.JLabel botonClasesRealizadas;
    private javax.swing.JLabel botonNombreClasesMateriales;
    private javax.swing.JLabel botonNombreEmpleadosSalario;
    private javax.swing.JLabel botonPersonasOrdenNombre;
    private javax.swing.JLabel buscarID;
    private javax.swing.JCheckBox checkBoxRealizoClase;
    private javax.swing.JComboBox<String> comboBoxElementoABuscar;
    private javax.swing.JLabel contraseñaEmpleado;
    private javax.swing.JLabel direccionCliente1;
    private javax.swing.JLabel direccionCliente2;
    private javax.swing.JLabel empleadoACargoClase;
    private javax.swing.JDialog errorBlancoOFormatoIncorrecto;
    private javax.swing.JDialog errorSeleccionarTabla;
    private javax.swing.JLabel fechaCliente1;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JLabel labelBotonEntrar;
    private javax.swing.JLabel labelContraseña;
    private javax.swing.JLabel labelIdEmpleado;
    private javax.swing.JLabel labelIniciarSesion;
    private javax.swing.JTable modeloAsistentes;
    private javax.swing.JTable modeloClase;
    private javax.swing.JTable modeloCliente;
    private javax.swing.JTable modeloEmpleado;
    private javax.swing.JTable modeloMaterial;
    private javax.swing.JTable modeloMaterialClase;
    private javax.swing.JTable modeloNombreClasesMateriales;
    private javax.swing.JTable modeloNombreEmpleadosSalario;
    private javax.swing.JTable modeloPersona;
    private javax.swing.JDialog modelosTablas;
    private javax.swing.JLabel nombreCliente1;
    private javax.swing.JLabel nombreCliente2;
    private javax.swing.JLabel nombreCliente3;
    private javax.swing.JLabel nombreCliente4;
    private javax.swing.JLabel nombreCliente5;
    private javax.swing.JLabel nombreCliente6;
    private javax.swing.JPanel panelAsistentes;
    private javax.swing.JPanel panelClases;
    private javax.swing.JPanel panelCliente;
    private javax.swing.JPanel panelEmpleado;
    private javax.swing.JPanel panelMaterial;
    private javax.swing.JPanel panelMaterialUsado;
    private javax.swing.JPanel panelPrincipalInsertarDatos;
    private javax.swing.JPanel panelPrincipalTablaDatos;
    private javax.swing.JDialog pantallaPrincipal;
    private javax.swing.JPasswordField passwordFieldContraseñaEmpleado;
    private javax.swing.JPasswordField passwordFieldContraseñaInicioSesion;
    private javax.swing.JLabel puestoEmpleado;
    private javax.swing.JLabel salarioEmpleado;
    private javax.swing.JScrollPane scrollPaneTablaDatos;
    private javax.swing.JTabbedPane selectorInsertarDatos;
    private javax.swing.JTabbedPane selectorPrincipal;
    private javax.swing.JTable tablaDatos;
    private javax.swing.JLabel telefonoCliente1;
    private javax.swing.JLabel telefonoCliente2;
    private javax.swing.JTextField textFieldCantidadMaterial;
    private javax.swing.JTextField textFieldDNICliente;
    private javax.swing.JTextField textFieldDNIEmpleado;
    private javax.swing.JTextField textFieldDireccionCliente;
    private javax.swing.JTextField textFieldDireccionEmpleado;
    private javax.swing.JTextField textFieldEmpleadoACargoClase;
    private javax.swing.JTextField textFieldFechaClase;
    private javax.swing.JTextField textFieldFechaCliente;
    private javax.swing.JTextField textFieldIDABorrar;
    private javax.swing.JTextField textFieldIDABuscar;
    private javax.swing.JTextField textFieldIDClaseAsistente;
    private javax.swing.JTextField textFieldIDClaseMaterialUsado;
    private javax.swing.JTextField textFieldIDClienteAsistente;
    private javax.swing.JTextField textFieldIDInicioSesion;
    private javax.swing.JTextField textFieldIDMaterialMaterialUsado;
    private javax.swing.JTextField textFieldNombreClase;
    private javax.swing.JTextField textFieldNombreCliente;
    private javax.swing.JTextField textFieldNombreEmpleado;
    private javax.swing.JTextField textFieldNombreMaterial;
    private javax.swing.JTextField textFieldPuestoEmpleado;
    private javax.swing.JTextField textFieldSalarioEmpleado;
    private javax.swing.JTextField textFieldTelefonoCliente;
    private javax.swing.JTextField textFieldTelefonoEmpleado;
    private javax.swing.JLabel textoBienvenida;
    private javax.swing.JLabel tituloBorrarLinea;
    private javax.swing.JLabel tituloCliente1;
    private javax.swing.JLabel tituloCliente2;
    private javax.swing.JLabel tituloCliente3;
    private javax.swing.JLabel tituloCliente4;
    private javax.swing.JLabel tituloCliente5;
    private javax.swing.JLabel tituloCliente6;
    private javax.swing.JLabel verDatosAsistentes;
    private javax.swing.JLabel verDatosClases;
    private javax.swing.JLabel verDatosClientes;
    private javax.swing.JLabel verDatosEmpleados;
    private javax.swing.JLabel verDatosMaterial;
    private javax.swing.JLabel verDatosMaterialUsado;
    private javax.swing.JLabel verDatosPersonas;
    // End of variables declaration//GEN-END:variables
}
