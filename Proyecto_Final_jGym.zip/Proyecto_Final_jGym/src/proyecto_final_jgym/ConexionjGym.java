package proyecto_final_jgym;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConexionjGym {

    PrintWriter fichero = null;
    Connection conexion;
    Statement sql;
    ResultSet registro;
    int filasAfectadas;
    String rutaInicial = System.getProperty("user.home");
    String ruta = rutaInicial + File.separator + "Documents" + File.separator + "registroJGYM.ini";
    File archivo = new File(ruta);
    ArrayList<String> mensajes = new ArrayList<>();

    private void InsertarTabla(String consulta) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://172.26.191.131:3306/jgym?serverTimezone=Europe/Madrid", "conexionbd", "1234");
            System.out.println("Conectado satisfatoriamente");

            sql = conexion.createStatement();

            filasAfectadas = sql.executeUpdate(consulta, Statement.RETURN_GENERATED_KEYS);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error en la conexión", ex);
        } finally {
            try {
                if (sql != null) {
                    sql.close();
                }
                if (conexion != null) {
                    conexion.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error al cerrar la conexión", ex);
            }
        }
    }

    public boolean comprobarUsuario(String idUsuario, String contrasenya) {
        boolean correcto = false;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://172.26.191.131:3306/jgym?serverTimezone=Europe/Madrid", "conexionbd", "1234");
            //172.26.190.120:3306
            System.out.println("Conectado satisfatoriamente");

            String consulta1 = "select id_persona, contraseña from empleado where id_persona like " + idUsuario + " and contraseña like '" + contrasenya + "';";

            sql = conexion.prepareStatement(consulta1);
            registro = sql.executeQuery(consulta1);
            if (registro.next()) {
                correcto = true;
                return correcto;
            } else {
                return correcto;
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error en la conexión", ex);
        } finally {
            if (sql != null) {
                try {
                    sql.close();
                } catch (SQLException ex) {
                    Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error al cerrar el Statement", ex);
                }
            }
            if (conexion != null) {
                try {
                    conexion.close();
                } catch (SQLException ex) {
                    Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error al cerrar el SQL", ex);
                }
            }
        }
        return correcto;
    }

    public void meterPersona(Personas persona) {
        String consulta = "insert into persona(nombre, dni, direccion, telefono) "
                + "values('" + persona.getNombre()
                + "', '" + persona.getDNI()
                + "', '" + persona.getDireccion()
                + "', '" + persona.getTelefono()
                + "');";
        InsertarTabla(consulta);
        consulta = null;
    }

    public void meterCliente(Cliente cliente) {
        String consultaID = "select max(id_persona) as id_persona from persona;";
        meterPersona(cliente);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://172.26.191.131:3306/jgym?serverTimezone=Europe/Madrid", "conexionbd", "1234");
            System.out.println("Conectado satisfatoriamente");

            sql = conexion.createStatement();
            registro = sql.executeQuery(consultaID);
            if (registro.next()) {
                cliente.setIdPersona(registro.getInt("id_persona"));
                consultaID = null;
                String consulta1 = "insert into cliente(id_persona, fecha_inscripcion) "
                        + "values('" + cliente.getIdPersona() + "', '"
                        + cliente.getDate()
                        + "')";
                filasAfectadas = sql.executeUpdate(consulta1);
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error en la conexión", ex);
        } finally {
            try {
                if (sql != null) {
                    sql.close();
                }
                if (conexion != null) {
                    conexion.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error al cerrar la conexión", ex);
            }
        }
        consultaID = null;
    }

    public void meterEmpleado(Empleado empleado) {
        String consultaID = "select max(id_persona) as id_persona from persona;";
        meterPersona(empleado);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://172.26.191.131:3306/jgym?serverTimezone=Europe/Madrid", "conexionbd", "1234");
            System.out.println("Conectado satisfatoriamente");

            sql = conexion.createStatement();
            registro = sql.executeQuery(consultaID);
            if (registro.next()) {
                empleado.setIdPersona(registro.getInt("id_persona"));
                String consulta1 = "insert into empleado(id_persona, salario, puesto, contraseña) "
                        + "values ('" + empleado.getIdPersona()
                        + "', '" + empleado.getSalario()
                        + "', '" + empleado.getPuesto()
                        + "', '" + empleado.getContrasenya()
                        + "');";
                filasAfectadas = sql.executeUpdate(consulta1);
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error en la conexión", ex);
        } finally {
            try {
                if (sql != null) {
                    sql.close();
                }
                if (conexion != null) {
                    conexion.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error al cerrar la conexión", ex);
            }
        }
        consultaID = null;
    }

    public void meterEquipamiento(Equipamiento equipamiento, int cantidad) {
        String consulta = "insert into equipamiento(nombre) values('" + equipamiento.getNombre()
                + "')";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://172.26.191.131:3306/jgym?serverTimezone=Europe/Madrid", "conexionbd", "1234");
            System.out.println("Conectado satisfatoriamente");

            for (int i = 0; i < cantidad; i++) {
                sql = conexion.createStatement();
                filasAfectadas = sql.executeUpdate(consulta, Statement.RETURN_GENERATED_KEYS);
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error en la conexión", ex);
        } finally {
            try {
                if (sql != null) {
                    sql.close();
                }
                if (conexion != null) {
                    conexion.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error al cerrar la conexión", ex);
            }
        }
        consulta = null;
    }

    public void meterClase(ClasesGym clasesGym) {
        String consulta = "insert into clase(nombre, fechaHora, realizado, id_persona) "
                + "values('" + clasesGym.getNombre()
                + "', '" + clasesGym.getFechaHora()
                + "', '" + clasesGym.getRealizado()
                + "', '" + clasesGym.getIdPersona()
                + "');";
        InsertarTabla(consulta);
        consulta = null;
    }

    public void meterAsistentes(int idClase, int idCliente) {
        String consulta = "insert into clase_cliente(id_clase, id_cliente) "
                + "values('" + idClase + "', '" + idCliente + "');";
        InsertarTabla(consulta);
        consulta = null;
    }

    public void meterEquipamientoClase(int idClase, int idMaterial) {
        String consulta = "insert into equipamiento_clase(id_clase, id_equipamiento) "
                + "values('" + idClase + "', '" + idMaterial + "');";
        InsertarTabla(consulta);
        consulta = null;
    }

    public ArrayList<Personas> sacarPersona(String id) {
        ArrayList<Personas> listaPersonas = new ArrayList<>();
        try {
            String consulta = "select * from persona where id_persona like " + "'" + id + "';";
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://172.26.191.131:3306/jgym?serverTimezone=Europe/Madrid", "conexionbd", "1234");
            System.out.println("Conectado satisfatoriamente");

            sql = conexion.prepareStatement(consulta);
            registro = sql.executeQuery(consulta);
            while (registro.next()) {
                Personas persona = new Personas();
                persona.setIdPersona(registro.getInt("id_persona"));
                persona.setNombre(registro.getString("nombre"));
                persona.setDNI(registro.getString("dni"));
                persona.setDireccion(registro.getString("direccion"));
                persona.setTelefono(registro.getInt("telefono"));
                listaPersonas.add(persona);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Clase no encontrada", ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Fallo en la consulta SQL", ex);
        } finally {
            try {
                if (sql != null) {
                    sql.close();
                }
                if (conexion != null) {
                    conexion.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error al cerrar la conexión", ex);
            }
        }
        return listaPersonas;
    }

    public ArrayList<Cliente> sacarClientes(String id) {
        ArrayList<Cliente> listaClientes = new ArrayList<>();
        try {
            String consulta = "select * from cliente where id_persona like " + "'" + id + "';";
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://172.26.191.131:3306/jgym?serverTimezone=Europe/Madrid", "conexionbd", "1234");
            System.out.println("Conectado satisfatoriamente");

            sql = conexion.prepareStatement(consulta);
            registro = sql.executeQuery(consulta);
            while (registro.next()) {
                Cliente cliente = new Cliente();
                cliente.setIdPersona(registro.getInt("id_persona"));
                cliente.setDate(registro.getString("fecha_inscripcion"));
                listaClientes.add(cliente);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Clase no encontrada", ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Fallo en la consulta SQL", ex);
        } finally {
            try {
                if (sql != null) {
                    sql.close();
                }
                if (conexion != null) {
                    conexion.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error al cerrar la conexión", ex);
            }
        }
        return listaClientes;
    }

    public ArrayList<Empleado> sacarEmpleados(String id) {
        ArrayList<Empleado> listaEmpleados = new ArrayList<>();
        try {
            String consulta = "select * from empleado where id_persona like " + "'" + id + "';";
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://172.26.191.131:3306/jgym?serverTimezone=Europe/Madrid", "conexionbd", "1234");
            System.out.println("Conectado satisfatoriamente");

            sql = conexion.prepareStatement(consulta);
            registro = sql.executeQuery(consulta);
            while (registro.next()) {
                Empleado empleado = new Empleado();
                empleado.setIdPersona(registro.getInt("id_persona"));
                empleado.setSalario(registro.getDouble("salario"));
                empleado.setPuesto(registro.getString("puesto"));
                empleado.setContrasenya(registro.getString("contraseña"));
                listaEmpleados.add(empleado);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Clase no encontrada", ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Fallo en la consulta SQL", ex);
        } finally {
            try {
                if (sql != null) {
                    sql.close();
                }
                if (conexion != null) {
                    conexion.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error al cerrar la conexión", ex);
            }
        }
        return listaEmpleados;
    }

    public ArrayList<ClasesGym> sacarClases(String id) {
        ArrayList<ClasesGym> listaClases = new ArrayList<>();
        try {
            String consulta = "select * from clase where id_clase like " + "'" + id + "';";
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://172.26.191.131:3306/jgym?serverTimezone=Europe/Madrid", "conexionbd", "1234");
            System.out.println("Conectado satisfatoriamente");

            sql = conexion.prepareStatement(consulta);
            registro = sql.executeQuery(consulta);
            while (registro.next()) {
                ClasesGym clasesGym = new ClasesGym();
                clasesGym.setIdClase(registro.getInt("id_clase"));
                clasesGym.setNombre(registro.getString("nombre"));
                clasesGym.setFechaHora(registro.getString("fechaHora"));
                clasesGym.setRealizado(registro.getInt("realizado"));
                clasesGym.setIdPersona(registro.getInt("id_persona"));
                listaClases.add(clasesGym);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Clase no encontrada", ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Fallo en la consulta SQL", ex);
        } finally {
            try {
                if (sql != null) {
                    sql.close();
                }
                if (conexion != null) {
                    conexion.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error al cerrar la conexión", ex);
            }
        }
        return listaClases;
    }

    public ArrayList<Equipamiento> sacarEquipamiento(String id) {
        ArrayList<Equipamiento> listaEquipamiento = new ArrayList<>();
        try {
            String consulta = "select * from equipamiento where id_equipamiento like " + "'" + id + "';";
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://172.26.191.131:3306/jgym?serverTimezone=Europe/Madrid", "conexionbd", "1234");
            System.out.println("Conectado satisfatoriamente");

            sql = conexion.prepareStatement(consulta);
            registro = sql.executeQuery(consulta);
            while (registro.next()) {
                Equipamiento equipamiento = new Equipamiento();
                equipamiento.setIdEquipamiento(registro.getInt("id_equipamiento"));
                equipamiento.setNombre(registro.getString("nombre"));
                listaEquipamiento.add(equipamiento);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Clase no encontrada", ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Fallo en la consulta SQL", ex);
        } finally {
            try {
                if (sql != null) {
                    sql.close();
                }
                if (conexion != null) {
                    conexion.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error al cerrar la conexión", ex);
            }
        }
        return listaEquipamiento;
    }

    public ArrayList<Integer> sacarClaseCliente(String id) {

        ArrayList<Integer> listaClaseCliente = new ArrayList<>();

        try {

            String consulta = "select * from clase_cliente where id_clase like " + "'" + id + "';";
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://172.26.191.131:3306/jgym?serverTimezone=Europe/Madrid", "conexionbd", "1234");
            System.out.println("Conectado satisfatoriamente");

            sql = conexion.prepareStatement(consulta);
            registro = sql.executeQuery(consulta);

            while (registro.next()) {
                listaClaseCliente.add(registro.getInt("id_clase"));
                listaClaseCliente.add(registro.getInt("id_cliente"));
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, null, ex);
        }

        return listaClaseCliente;
    }

    public ArrayList<Integer> sacarEquipamientoClase(String id) {

        ArrayList<Integer> listaEquipamientoClase = new ArrayList<>();

        try {

            String consulta = "select * from equipamiento_clase where id_clase like " + "'" + id + "';";
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://172.26.191.131:3306/jgym?serverTimezone=Europe/Madrid", "conexionbd", "1234");
            System.out.println("Conectado satisfatoriamente");

            sql = conexion.prepareStatement(consulta);
            registro = sql.executeQuery(consulta);

            while (registro.next()) {
                listaEquipamientoClase.add(registro.getInt("id_clase"));
                listaEquipamientoClase.add(registro.getInt("id_equipamiento"));
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, null, ex);
        }

        return listaEquipamientoClase;
    }

    public void borrarPersona(int id) {

        try {
            String consulta = "delete from persona where id_persona = " + id + ";";
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://172.26.191.131:3306/jgym?serverTimezone=Europe/Madrid", "conexionbd", "1234");
            System.out.println("Conectado satisfatoriamente");

            sql = conexion.prepareStatement(consulta);
            int filasAfectadas = sql.executeUpdate(consulta);

            if (filasAfectadas > 0) {
                System.out.println("Objeto borrado correctamente");
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Clase no encontrada", ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error en SQL", ex);
        }
    }

    public void borrarEmpleado(int id) {

        try {
            String consulta = "delete from empleado where id_persona = " + id + ";";
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://172.26.191.131:3306/jgym?serverTimezone=Europe/Madrid", "conexionbd", "1234");
            System.out.println("Conectado satisfatoriamente");

            sql = conexion.prepareStatement(consulta);
            int filasAfectadas = sql.executeUpdate(consulta);

            if (filasAfectadas > 0) {
                System.out.println("Objeto borrado correctamente");
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Clase no encontrada", ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error en SQL", ex);
        }
    }

    public void borrarCliente(int id) {

        try {
            String consulta = "delete from cliente where id_persona = " + id + ";";
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://172.26.191.131:3306/jgym?serverTimezone=Europe/Madrid", "conexionbd", "1234");
            System.out.println("Conectado satisfatoriamente");

            sql = conexion.prepareStatement(consulta);
            int filasAfectadas = sql.executeUpdate(consulta);

            if (filasAfectadas > 0) {
                System.out.println("Objeto borrado correctamente");
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Clase no encontrada", ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error en SQL", ex);
        }
    }

    public void borrarMaterial(int id) {

        try {
            String consulta = "delete from equipamiento where id_equipamiento = " + id + ";";
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://172.26.191.131:3306/jgym?serverTimezone=Europe/Madrid", "conexionbd", "1234");
            System.out.println("Conectado satisfatoriamente");

            sql = conexion.prepareStatement(consulta);
            int filasAfectadas = sql.executeUpdate(consulta);

            if (filasAfectadas > 0) {
                System.out.println("Objeto borrado correctamente");
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Clase no encontrada", ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error en SQL", ex);
        }
    }

    public ArrayList<Object> sacarNombreEmpleadosSalario() {
        ArrayList<Object> listaEmpleados = new ArrayList<>();
        try {
            String consulta = "select * from empleadosSalario";
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://172.26.191.131:3306/jgym?serverTimezone=Europe/Madrid", "conexionbd", "1234");
            System.out.println("Conectado satisfatoriamente");

            sql = conexion.prepareStatement(consulta);
            registro = sql.executeQuery(consulta);
            while (registro.next()) {
                listaEmpleados.add(registro.getString("nombre"));
                listaEmpleados.add(registro.getString("puesto"));
                listaEmpleados.add(registro.getDouble("salario"));
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Clase no encontrada", ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Fallo en la consulta SQL", ex);
        } finally {
            try {
                if (sql != null) {
                    sql.close();
                }
                if (conexion != null) {
                    conexion.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error al cerrar la conexión", ex);
            }
        }
        return listaEmpleados;
    }

    public ArrayList<Object> sacarPersonasOrdenNombre() {
        ArrayList<Object> listaPersonas = new ArrayList<>();
        try {
            String consulta = "select * from personasOrdenNombre;";
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://172.26.191.131:3306/jgym?serverTimezone=Europe/Madrid", "conexionbd", "1234");
            System.out.println("Conectado satisfatoriamente");

            sql = conexion.prepareStatement(consulta);
            registro = sql.executeQuery(consulta);
            while (registro.next()) {
                listaPersonas.add(registro.getInt("id_persona"));
                listaPersonas.add(registro.getString("nombre"));
                listaPersonas.add(registro.getString("dni"));
                listaPersonas.add(registro.getString("direccion"));
                listaPersonas.add(registro.getInt("telefono"));
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Clase no encontrada", ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Fallo en la consulta SQL", ex);
        } finally {
            try {
                if (sql != null) {
                    sql.close();
                }
                if (conexion != null) {
                    conexion.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error al cerrar la conexión", ex);
            }
        }
        return listaPersonas;
    }

    public ArrayList<ClasesGym> sacarClasesRealizadas() {
        ArrayList<ClasesGym> listaClases = new ArrayList<>();
        try {
            String consulta = "select * from clasesRealizadas;";
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://172.26.191.131:3306/jgym?serverTimezone=Europe/Madrid", "conexionbd", "1234");
            System.out.println("Conectado satisfatoriamente");

            sql = conexion.prepareStatement(consulta);
            registro = sql.executeQuery(consulta);
            while (registro.next()) {
                ClasesGym clasesGym = new ClasesGym();
                clasesGym.setIdClase(registro.getInt("id_clase"));
                clasesGym.setNombre(registro.getString("nombre"));
                clasesGym.setFechaHora(registro.getString("fechaHora"));
                clasesGym.setRealizado(registro.getInt("realizado"));
                clasesGym.setIdPersona(registro.getInt("id_persona"));
                listaClases.add(clasesGym);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Clase no encontrada", ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Fallo en la consulta SQL", ex);
        } finally {
            try {
                if (sql != null) {
                    sql.close();
                }
                if (conexion != null) {
                    conexion.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error al cerrar la conexión", ex);
            }
        }
        return listaClases;
    }

    public ArrayList<String> sacarNombreClasesEquipamiento() {
        ArrayList<String> lista = new ArrayList<>();
        try {
            String consulta = "select * from nombreClaseMaterial;";
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://172.26.191.131:3306/jgym?serverTimezone=Europe/Madrid", "conexionbd", "1234");
            System.out.println("Conectado satisfatoriamente");

            sql = conexion.prepareStatement(consulta);
            registro = sql.executeQuery(consulta);
            while (registro.next()) {
                lista.add(registro.getString("nombreDeLaClase"));
                lista.add(registro.getString("nombreDelEquipamiento"));
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Clase no encontrada", ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Fallo en la consulta SQL", ex);
        } finally {
            try {
                if (sql != null) {
                    sql.close();
                }
                if (conexion != null) {
                    conexion.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error al cerrar la conexión", ex);
            }
        }
        return lista;
    }
    
    public void guardarArchivo(String mensaje){
        LocalDateTime now = LocalDateTime.now();
        mensajes.add(mensaje + " --> " + now);
        if (ruta != null) {
            try {
                fichero = new PrintWriter(ruta);
                fichero.println(mensaje + "\n");
                try (BufferedWriter escritor = new BufferedWriter(new FileWriter(archivo, true))) {
                    for (int i = 0; i < mensajes.size(); i++) {
                        escritor.append(mensajes.get(i) + "\n");
                    }
                }
            } catch (FileNotFoundException ex) {
                Logger.getLogger(ConexionjGym.class.getName()).log(Level.WARNING, "Fichero no encontrado", ex);
            } catch (IOException ex) {
                Logger.getLogger(ConexionjGym.class.getName()).log(Level.SEVERE, "Error genérico", ex);
            }
        }
    }
}
